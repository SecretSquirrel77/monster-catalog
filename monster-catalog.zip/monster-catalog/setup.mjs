import {sceneControls} from "./scripts/sceneControls.mjs";
import {registerSettings} from "./scripts/settings.mjs";

Hooks.once("init", registerSettings);
Hooks.on("getSceneControlButtons", sceneControls);
