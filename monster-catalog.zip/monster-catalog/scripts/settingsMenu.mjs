export class CompendiumKeysMenu extends FormApplication {
  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      popOut: true,
      width: 400,
      resizable: true,
      classes: ["monster-catalog", "settings-menu"]
    });
  }

  /** @override */
  get template() {
    return `modules/monster-catalog/templates/compendiumKeysMenu.hbs`;
  }

  /** @override */
  get id() {
    return "monster-catalog-settings-compendium-keys";
  }

  /** @override */
  get title() {
    return game.i18n.localize("MONSTER_CATALOG.MonsterCatalog");
  }

  /** @override */
  async _updateObject(event) {
    const keys = [];
    event.currentTarget.closest("form").querySelectorAll(".keys-enabled .active").forEach(key => {
      keys.push(key.dataset.key);
    });
    return game.settings.set("monster-catalog", "keys", keys);
  }

  /** @override */
  async getData() {
    const keys = game.settings.get("monster-catalog", "keys") ?? [];
    const data = [];
    for (const key of game.packs.keys()) {
      const pack = game.packs.get(key);
      if (pack.metadata.type !== "Actor") continue;
      data.push({
        id: pack.metadata.id,
        label: pack.metadata.label,
        active: keys.includes(pack.metadata.id)
      });
    }
    return {keys: data.sort((a, b) => a.label.localeCompare(b.label))};
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html[0].querySelectorAll("[data-action='toggle-key']").forEach(n => {
      n.addEventListener("click", this._onToggleKey.bind(this));
    });
  }

  /**
   * Toggle the active state of a compendium key.
   * @param {PointerEvent} event      The initiating click event.
   */
  async _onToggleKey(event) {
    const id = event.currentTarget.closest(".form-group").dataset.key;
    this.element[0].querySelectorAll(`[data-key="${id}"]`).forEach(n => {
      n.closest(".form-group").classList.toggle("active");
    });
  }
}
