export class MonsterCatalog extends Application {
  /** @override */
  constructor(packs) {
    super();
    this.packs = new Set(packs);
  }

  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "monster-catalog",
      classes: ["monster-catalog", "catalog"],
      tabs: [{navSelector: ".tabs", contentSelector: ".content-tabs"}],
      title: "MONSTER_CATALOG.MonsterCatalog",
      template: "modules/monster-catalog/templates/monsterCatalog.hbs",
      resizable: true,
      width: 600,
      height: 900
    });
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html[0].querySelectorAll("[data-action='toggle-collapse']").forEach(n => {
      n.addEventListener("click", this._onToggleCollapse.bind(this));
    });
    html[0].querySelectorAll("[data-action='hover-img']").forEach(n => {
      n.addEventListener("mouseover", this._onHoverImg.bind(this));
    });
    html[0].querySelectorAll("[data-action='hover-bio']").forEach(n => {
      n.addEventListener("mouseover", this._onHoverBio.bind(this));
    });
    html[0].querySelectorAll("[data-action='hover-src']").forEach(n => {
      n.addEventListener("mouseover", this._onHoverSrc.bind(this));
    });
    html[0].querySelectorAll("[data-action='hover-align']").forEach(n => {
      n.addEventListener("mouseover", this._onHoverAlign.bind(this));
    });
    html[0].querySelectorAll("[data-action^='hover']").forEach(n => {
      n.addEventListener("mouseout", this._onLeaveHover.bind(this));
    });
    html[0].querySelectorAll("[data-action='hover-import']").forEach(n => {
      n.addEventListener("click", this._onClickImport.bind(this));
      n.addEventListener("mouseover", this._onHoverImport.bind(this));
    });
    html[0].querySelectorAll("[data-action='hover-pack']").forEach(n => {
      n.addEventListener("mouseover", this._onHoverPack.bind(this));
    });
    html[0].querySelectorAll("[data-action='hover-size']").forEach(n => {
      n.addEventListener("mouseover", this._onHoverSize.bind(this));
    });
  }

  /**
   * Toggle the collapsed state of a section.
   * @param {PointerEvent} event      The initiating click event.
   */
  _onToggleCollapse(event) {
    event.currentTarget.closest(".collapsible").classList.toggle("active");
  }

  /**
   * Helper method to get the icon for a creature type.
   * @returns {object}      An object of strings.
   */
  get icon() {
    return {
      aberration: "dna",
      beast: "paw",
      celestial: "ankh",
      construct: "robot",
      dragon: "dragon",
      elemental: "fire",
      fey: "clover",
      fiend: "tooth",
      giant: "chess-rook",
      humanoid: "person",
      monstrosity: "spaghetti-monster-flying",
      ooze: "droplet",
      plant: "leaf",
      undead: "skull-crossbones",
      other: "question"
    };
  }

  /**
   * Get a property from an index entry, respecting outdated data vs system paths.
   * @param {object} target     An index entry.
   * @param {string} path       The property to retrieve.
   * @returns {any|null}
   */
  getProperty(target, path) {
    const sys = foundry.utils.getProperty(target, `system.${path}`);
    return sys ?? foundry.utils.getProperty(target, `data.${path}`) ?? null;
  }

  /** @override */
  async getData() {
    const data = await super.getData();
    data.collapsed = game.settings.get("monster-catalog", "initial-collapse");

    const rating = game.settings.get("monster-catalog", "minimum-rating");
    const minimumRating = Number.isNumeric(rating) ? Math.max(rating, 0) : 0;


    // Get all monsters.
    const monsters = [];
    for (const pack of this.packs) {
      if (!pack) continue;
      const idx = await pack.getIndex({
        fields: [
          "system.attributes.ac.flat", "data.attributes.ac.flat",
          "system.attributes.hp.max", "data.attributes.hp.max",
          "system.details.alignment", "data.details.alignment",
          "system.details.biography.value", "data.details.biography.value",
          "system.details.cr", "data.details.cr",
          "system.details.source.custom", "data.details.source",
          "system.details.type.value", "data.details.type.value",
          "system.traits.size", "data.traits.size"
        ]
      });
      idx.forEach(i => {
        i.pack = pack.metadata.id;
        i.compendium = pack.metadata.label;
        i.sizeLetter = CONFIG.DND5E.actorSizes[this.getProperty(i, "traits.size")]?.abbreviation || "";
        i.icon = this.icon[this.getProperty(i, "details.type.value")] ?? this.icon.other;
      });
      monsters.push(...idx);
    }

    data.types = [];
    for (const m of monsters) {
      if (m.type !== "npc") continue;
      const _cr = this.getProperty(m, "details.cr");
      const cr = Number.isNumeric(_cr) ? Number(_cr) : 0;
      if (cr < minimumRating) continue;
      const _type = this.getProperty(m, "details.type.value");
      const type = (_type in CONFIG.DND5E.creatureTypes) ? _type : "other";
      let section = data.types.find(e => (e.key === type));
      if (!section) {
        const obj = CONFIG.DND5E.creatureTypes[type] ?? {};
        section = {
          key: type,
          label: obj.label || game.i18n.localize("MONSTER_CATALOG.Other"),
          icon: obj.icon ?? "icons/magic/symbols/question-stone-yellow.webp",
          ratings: []
        };
        data.types.push(section);
      }
      let ratingGroup = section.ratings.find(e => (e.cr === cr));
      if (!ratingGroup) {
        ratingGroup = {cr: cr, monsters: []};
        section.ratings.push(ratingGroup);
      }
      ratingGroup.monsters.push(m);
    }

    data.types.sort((a, b) => {
      if (a.key === "other") return 1;
      return a.label.localeCompare(b.label);
    });
    for (const val of data.types) {
      val.ratings.sort((a, b) => a.cr - b.cr);
      for (const m of val.ratings) {
        if (m.cr == 0.125) m.cr = "1/8";
        else if (m.cr == 0.25) m.cr = "1/4";
        else if (m.cr == 0.5) m.cr = "1/2";
        m.monsters.sort((a, b) => a.name.localeCompare(b.name));
      }
    }
    data.repeat = data.types.length;
    return data;
  }

  /** @override */
  _onChangeTab(event, tabs, active) {
    super._onChangeTab(event, tabs, active);
    this.element[0].querySelector(".content-tabs").scrollTop = 0;
  }

  /**
   * Render this application.
   * @returns {MonsterCatalog}          The rendered application.
   */
  static renderMonsterCatalog() {
    let packKeys = [];
    let packs = [];
    try {
      packKeys = game.settings.get("monster-catalog", "keys") ?? [];
      packs = packKeys.reduce((acc, key) => {
        const pack = game.packs.get(key);
        if (pack && (pack.metadata.type === "Actor")) acc.push(pack);
        return acc;
      }, []);
    } catch (err) {
      ui.notifications.warn("MONSTER_CATALOG.WarnNoPacksAdded", {localize: true});
      console.warn(err);
      return;
    }
    if (!packs.length) {
      ui.notifications.warn("MONSTER_CATALOG.WarnNoPacksAdded", {localize: true});
      return;
    }
    if (!packs.some(pack => pack.index.find(a => a.type === "npc"))) {
      ui.notifications.warn("MONSTER_CATALOG.WarnNoNPCsFound", {localize: true});
      return;
    }
    return new MonsterCatalog(packs).render(true);
  }

  /**
   * Display the image of an actor when hovering over the content link.
   * This is added explicitly due to possible module art.
   * @param {PointerEvent} event      The initiating mouseover event.
   */
  async _onHoverImg(event) {
    const target = event.currentTarget;
    const {img} = await fromUuid(target.dataset.uuid);
    game.tooltip.activate(target, {text: `<img src="${img}">`});
    const tip = game.tooltip.tooltip;
    const rect = target.closest(".window-content").getBoundingClientRect();
    tip.style.top = rect.top + 5 + "px";
    tip.style.right = window.innerWidth - rect.right + 5 + "px";
    tip.style.left = "";
    tip.style.bottom = "";
  }

  /**
   * Show the biography of an actor when hovering over the 'Bio' icon.
   * @param {PointerEvent} event      The initiating mouseover event.
   */
  async _onHoverBio(event) {
    const target = event.currentTarget;
    const uuid = target.closest("[data-uuid]").dataset.uuid;
    const bio = (await fromUuid(uuid)).system.details.biography.value;
    game.tooltip.activate(target, {text: bio, cssClass: "monster-catalog left-align"});
  }

  /**
   * Show the source of an actor when hovering over the 'Src' icon.
   * @param {PointerEvent} event      The initiating mouseover event.
   */
  async _onHoverSrc(event) {
    const target = event.currentTarget;
    const uuid = target.closest("[data-uuid]").dataset.uuid;
    const src = (await fromUuid(uuid)).system.details.source.label;
    game.tooltip.activate(target, {text: src});
  }

  /**
   * Show the alignment of an actor when hovering over the 'Align' icon.
   * @param {PointerEvent} event      The initiating mouseover event.
   */
  async _onHoverAlign(event) {
    const target = event.currentTarget;
    const uuid = target.closest("[data-uuid]").dataset.uuid;
    const align = (await fromUuid(uuid)).system.details.alignment;
    game.tooltip.activate(target, {text: align});
  }

  /**
   * Deactivate the tooltip when leaving the hover target.
   * @param {PointerEvent} event      The initiating mouseout event.
   */
  _onLeaveHover(event) {
    game.tooltip.deactivate();
  }

  /**
   * Import a monster.
   * @param {PointerEvent} event      The initiating click event.
   * @returns {Actor}                 The imported actor.
   */
  async _onClickImport(event) {
    const pack = game.packs.get(event.currentTarget.dataset.pack);
    const id = event.currentTarget.dataset.id;
    ui.notifications.info("MONSTER_CATALOG.ImportingMonster", {localize: true});
    return game.actors.importFromCompendium(pack, id);
  }

  /**
   * Display tooltip when hovering over the import buttons.
   * @param {PointerEvent} event      The initiating mouseover event.
   */
  _onHoverImport(event) {
    const tip = game.i18n.localize("MONSTER_CATALOG.Import");
    game.tooltip.activate(event.currentTarget, {text: tip});
  }

  /**
   * Show the label of the pack containing the actor when hovering over the 'Pack' icon.
   * @param {PointerEvent} event      The initiating mouseover event.
   */
  _onHoverPack(event) {
    const label = event.currentTarget.dataset.pack;
    game.tooltip.activate(event.currentTarget, {text: label});
  }

  /**
   * Show the actor size when hovering over the 'Size' icon.
   * @param {PointerEvent} event      The initiating mouseover event.
   */
  _onHoverSize(event) {
    const label = CONFIG.DND5E.actorSizes[event.currentTarget.dataset.size]?.label;
    game.tooltip.activate(event.currentTarget, {text: label});
  }
}
