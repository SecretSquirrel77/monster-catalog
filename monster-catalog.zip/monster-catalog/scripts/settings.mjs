import {CompendiumKeysMenu} from "./settingsMenu.mjs";

export function registerSettings() {
  game.settings.register("monster-catalog", "keys", {
    scope: "world",
    config: false,
    type: Object,
    default: []
  });

  game.settings.registerMenu("monster-catalog", "keys", {
    name: "MONSTER_CATALOG.CompendiumPl",
    hint: "MONSTER_CATALOG.SettingsMenuHint",
    label: "MONSTER_CATALOG.EditCompendiums",
    icon: "fa-solid fa-key",
    type: CompendiumKeysMenu,
    restricted: true
  });

  game.settings.register("monster-catalog", "initial-collapse", {
    name: "MONSTER_CATALOG.SettingsInitialCollapse",
    hint: "MONSTER_CATALOG.SettingsInitialCollapseHint",
    scope: "world",
    config: true,
    type: Boolean,
    default: false
  });

  game.settings.register("monster-catalog", "minimum-rating", {
    name: "MONSTER_CATALOG.SettingsMinimumRating",
    hint: "MONSTER_CATALOG.SettingsMinimumRatingHint",
    scope: "world",
    config: true,
    type: Number,
    default: 0
  });
}
