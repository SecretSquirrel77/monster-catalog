import {MonsterCatalog} from "./monsterCatalog.mjs";

export function sceneControls(array) {
  const token = array.find(a => a.name === "token");
  // Show monster catalog.
  if (game.user.isGM) token.tools.push({
    name: "monster-catalog",
    title: "MONSTER_CATALOG.MonsterCatalog",
    icon: "fa-solid fa-spaghetti-monster-flying",
    button: true,
    visible: true,
    onClick: MonsterCatalog.renderMonsterCatalog
  });
}
